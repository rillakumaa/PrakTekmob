package com.example.praktikum_rila

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
